import requests
from datetime import datetime, timedelta
from fastapi import FastAPI, Request, Form
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.templating import Jinja2Templates
from geopy.distance import geodesic
from config import SERVICE_KEY
from location_coords import location_coords
from weather import get_current_weather, get_weather_display_text
from filter import filter_places_by_weather

app = FastAPI()
templates = Jinja2Templates(directory="templates")

CATEGORY_CODE_MAP = {
    "음식점": "39",
    "숙소": "32",
    "관광지": "12",
    "쇼핑": "38",
}

# 체류 시간 설정
def get_place_duration(cat3, hour):
    if cat3 in {"A02030400", "A02010800"}:  # 전시/종교시설
        return timedelta(hours=1)
    elif cat3 in {"A02020200", "A02020600"}:  # 테마파크/골목
        return timedelta(hours=2)
    elif cat3 in {"A01010500", "A02020700"}:  # 공원/운동장
        return timedelta(minutes=90)
    else:
        return timedelta(hours=1)

# 시간대 조건
def is_night(hour):
    return 19 <= hour < 24

def is_day(hour):
    return 7 <= hour < 19

def is_sleep_time(hour):
    return hour < 7 or hour >= 24

# 카테고리별 시간대 추천 분류
DAY_PLACE_CATEGORIES = {"A01010500", "A02020200", "A02020600", "A02020700"}
NIGHT_PLACE_CATEGORIES = {"A02030300", "A02030700", "A01010400"}  # 전망대, 야경 등 예시

def create_schedule(places, days=1, start_location=(37.5665, 126.9780)):
    def distance(place):
        return geodesic(start_location, (place["lat"], place["lon"])).km

    sorted_places = sorted(places, key=distance)
    schedule = [[] for _ in range(days)]

    for day_idx in range(days):
        current_time = datetime.strptime("10:00", "%H:%M")
        end_time = datetime.strptime("22:00", "%H:%M")
        daily_plan = []

        i = 0
        while i < len(sorted_places) and current_time < end_time:
            hour = current_time.hour
            place = sorted_places[i]
            cat3 = place.get("cat3", "")

            if current_time.strftime("%H:%M") == "12:00":
                daily_plan.append({
                    "title": "🍴 점심시간",
                    "visit_time": "12:00",
                    "addr": "",
                })
                current_time += timedelta(hours=1)
                continue

            if is_sleep_time(hour):
                current_time += timedelta(minutes=30)
                continue

            if is_day(hour) and cat3 not in DAY_PLACE_CATEGORIES:
                i += 1
                continue
            if is_night(hour) and cat3 not in NIGHT_PLACE_CATEGORIES:
                i += 1
                continue

            duration = get_place_duration(cat3, hour)
            end_visit_time = current_time + duration
            if end_visit_time > end_time:
                break

            place["visit_time"] = current_time.strftime("%H:%M")
            daily_plan.append(place)
            current_time = end_visit_time
            i += 1

        schedule[day_idx] = daily_plan
        sorted_places = sorted_places[i:]

    return schedule


@app.get("/", response_class=HTMLResponse)
async def select_category(request: Request):
    return templates.TemplateResponse("select_category.html", {"request": request})


@app.post("/select_region", response_class=HTMLResponse)
async def select_region(request: Request, category: str = Form(...)):
    return templates.TemplateResponse("select_region.html", {"request": request, "category": category})


@app.post("/show_recommendations", response_class=HTMLResponse)
async def show_recommendations(
        request: Request,
        category: str = Form(...),
        city: str = Form(...),
        district: str = Form(...),
        city_name: str = Form(...),
        district_name: str = Form(...)
):
    area_data = await get_area_code(city, district)
    if not area_data:
        return templates.TemplateResponse("recommendations.html", {
            "request": request,
            "category": category,
            "city": city_name,
            "district": district_name,
            "places": [],
            "schedule": [],
            "weather": None,
            "error": "지역 정보를 찾을 수 없습니다."
        })

    area_code, sigungu_code = area_data
    places = await get_recommendations(category, area_code, sigungu_code)

    weather = None
    weather_display = None

    if category == "관광지":
        coords = location_coords.get(city)
        if coords:
            lat, lon = coords
            weather = get_current_weather(lat, lon)
            weather_display = get_weather_display_text(weather)
            if weather:
                places = filter_places_by_weather(places, weather)

    schedule = create_schedule(places, days=1) if places else []

    return templates.TemplateResponse("recommendations.html", {
        "request": request,
        "category": category,
        "city": city_name,
        "district": district_name,
        "places": places,
        "weather": weather_display,
        "schedule": schedule,
        "error": None
    })


@app.get("/get_cities", response_class=JSONResponse)
async def get_cities():
    url = "http://apis.data.go.kr/B551011/KorService1/areaCode1"
    params = {
        "serviceKey": SERVICE_KEY,
        "MobileOS": "ETC",
        "MobileApp": "AppTest",
        "_type": "json",
        "numOfRows": 100
    }

    response = requests.get(url, params=params)
    try:
        data = response.json()
        items = data.get("response", {}).get("body", {}).get("items", {}).get("item", [])
        cities = [{"name": item["name"], "code": item["code"]} for item in items]
        return JSONResponse(content={"cities": cities})
    except Exception as e:
        return JSONResponse(content={"error": "도시 목록 오류", "message": str(e)}, status_code=500)


@app.get("/get_districts", response_class=JSONResponse)
async def get_districts(area_code: int):
    url = "http://apis.data.go.kr/B551011/KorService1/areaCode1"
    params = {
        "serviceKey": SERVICE_KEY,
        "areaCode": area_code,
        "MobileOS": "ETC",
        "MobileApp": "AppTest",
        "_type": "json",
        "numOfRows": 100
    }

    response = requests.get(url, params=params)
    try:
        data = response.json()
        items = data.get("response", {}).get("body", {}).get("items", {}).get("item", [])
        districts = [{"name": item["name"], "code": item["code"]} for item in items]
        return JSONResponse(content={"districts": districts})
    except Exception as e:
        return JSONResponse(content={"error": "시군구 목록 오류", "message": str(e)}, status_code=500)


async def get_area_code(city_code: str, district_code: str):
    return int(city_code), int(district_code)


async def get_recommendations(category: str, area_code: str, sigungu_code: str):
    content_type_id = CATEGORY_CODE_MAP.get(category)
    if not content_type_id:
        return []

    url = "http://apis.data.go.kr/B551011/KorService1/areaBasedList1"
    params = {
        "serviceKey": SERVICE_KEY,
        "MobileOS": "ETC",
        "MobileApp": "KoreaTripMate",
        "_type": "json",
        "areaCode": area_code,
        "sigunguCode": sigungu_code,
        "contentTypeId": content_type_id,
        "numOfRows": 100
    }

    if content_type_id == "12":
        params["listYN"] = "Y"

    response = requests.get(url, params=params)
    try:
        data = response.json()
        items = data.get("response", {}).get("body", {}).get("items", {}).get("item", [])
    except Exception:
        return []

    results = []
    for item in items:
        results.append({
            "title": item.get("title", "이름 없음"),
            "tel": item.get("tel", ""),
            "openTime": item.get("openTime", ""),
            "addr": item.get("addr1", ""),
            "cat3": item.get("cat3", ""),
            "lat": float(item.get("mapy", 0)),
            "lon": float(item.get("mapx", 0))
        })
    return results
