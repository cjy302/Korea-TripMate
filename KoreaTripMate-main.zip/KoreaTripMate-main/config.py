import os
from dotenv import load_dotenv
from urllib.parse import unquote

load_dotenv()

SERVICE_KEY = unquote(os.getenv("SERVICE_KEY"))
OPENWEATHER_KEY = os.getenv("OPENWEATHER_KEY")