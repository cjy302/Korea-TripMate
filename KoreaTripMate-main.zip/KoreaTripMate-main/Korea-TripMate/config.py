from dotenv import load_dotenv
import os

load_dotenv()
SERVICE_KEY = os.getenv("SERVICE_KEY")